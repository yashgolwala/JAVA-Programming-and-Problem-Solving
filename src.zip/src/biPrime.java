import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;

public class biPrime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		int N = scan.nextInt();
		scan.nextLine();

		int[] arr = new int[2*N];
		for(int i =0 ; i<2*N;i+=2) {
			int t1 = scan.nextInt();
			scan.nextLine();
			int t2 = scan.nextInt();
			scan.nextLine();
			arr[i]=t1;
			arr[i+1]=t2;
		}
		ArrayList<Integer> res = new ArrayList<Integer>();
		for(int i=0;i<N-1;i+=2) {
			int temp = compute(arr[i],arr[i+1]);
			System.out.print(temp+" ");
		}
		int c = compute(arr[N-1],arr[N-1]);
		System.out.print(c);

	}

	private static int compute(int a, int b) {
		
		int upper = a;
		int lower = b;
		ArrayList<Integer> al = new ArrayList<Integer>();
		for(int i=a;i<=b;i++) {
			if(i==0 || i==1) {
				continue;
			}
			else {
				if(b%i==0) {
					al.add(i);
				}
			}
		}
		int [] ar = new int[al.size()];
		for(int i =0; i<al.size();i++) {
			ar[i]=al.get(i);
		}
		HashSet<Integer> set = new HashSet<Integer>();
		for(int i=0; i<ar.length;i++) {
			for(int j=0;j<ar.length;j++) {
				int temp = ar[i]*ar[j];
				if(temp>=lower && temp<=upper) {
					set.add(temp);
				}
			}
		}
		
		return set.size();
	}

}