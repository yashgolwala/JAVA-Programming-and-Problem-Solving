package pct_example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.function.BiConsumer;

public class Exam1 {

	public static void main(String[] args) {
		int n,p;
		String input;
		Scanner sc= new Scanner(System.in);
		
		input=sc.nextLine();
		n= Integer.parseInt(input.split(" ")[0]);
		p= Integer.parseInt(input.split(" ")[1]);
		
		//array of seats
		
		int[] seats = new int[n];
		
		seats=findSeat(seats,p);
		
		for(int i=0;i<seats.length;i++) {
			if(seats[i]==p) {
				System.out.println((i+1));
			}
			
		}
		ArrayList<Integer> s= new ArrayList<>();
		
		
				
		
	}
	public static int[] findSeat(int[] seats,int p) {
		
		for(int j=1;j<=p;j++) {
			
			if(findEmptySeats(seats)==seats.length) {
				seats[0]=j;
			} else {
				ArrayList<Integer> availableList= new ArrayList<>();
				HashMap<Integer,Integer> options= new HashMap<>();
				//find available seats
				for(int i=0;i<seats.length;i++) {
					if(seats[i]==0) {
						availableList.add(i);	
					}
				}

				
				
				
				for(int k=0;k<availableList.size();k++) {
					
					options.put(availableList.get(k),findMaxNeigh(seats,availableList.get(k)));
					
				}
				 
				
				int select=0;
				int max=0;
				for(int x: options.keySet()) {
					
					if(options.get(x)>max){
						select=x;
						max=options.get(x);
					} else if(options.get(x)==max) {
						if(x<select) {
							select=x;
						}
					}
					
				}
				
				 seats[select]=j;
				 
				 
			}
				
		}
		return seats;
	}
	
	public static int findEmptySeats(int[] seats) {
		int EmptyseatCount=0;
		
		for(int i=0;i<seats.length;i++) {
			if(seats[i]==0) {
				EmptyseatCount++;
			}
			
		}
		return EmptyseatCount;
	}
	
	public static int findMaxNeigh(int[] seats,int x) {
		int leftNeighbourdist=1;
		int rightNeighbourdist=1;
		//find left
		for(int i=x-1;i>=0;i--) {
			if(seats[i]==0) {
				leftNeighbourdist++;
			}if(seats[i]!=0) {
				break;
			}
		}
		//find right
		for(int i=x+1;i<seats.length;i++) {
			if(seats[i]==0) {
				rightNeighbourdist++;
				if(i==seats.length-1 && seats[i]==0 ) {
				rightNeighbourdist=0;	
				}
			}if(seats[i]!=0) {
				break;
			}
		}
		
		if(leftNeighbourdist<rightNeighbourdist) {
			return leftNeighbourdist;
			}
		else {
			return rightNeighbourdist;
			}
		
	}
}

