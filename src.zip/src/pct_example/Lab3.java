package pct_example;

import java.util.Scanner;

public class Lab3 {
	
	private class Node{
		int element;
		Node left,right;
		Node(int val){
			element = val;
			left=null;
			right=null;
		}
		Node(int val, Node leftChild,Node rightChild){
			element = val;
			left = leftChild;
			right = rightChild;
		}
		Node root = null;
	}

	public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	String input = scan.nextLine();
	System.out.println(""+input );
	int n = input.length();
	int i = 0;
	int[] arr = new int[50];
	while(n>=0) {
		if(input.indexOf(i)=='('){
			if(left(v))
		}
			
	}
	
	}

}
