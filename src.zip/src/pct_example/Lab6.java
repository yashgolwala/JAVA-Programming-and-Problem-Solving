import java.util.*;
 
class lab6
{
    static final int MAXV = 100;
    static final int MAXDEGREE = 50;
    
    public int numv;
    public int count;
    
    public int edges[][] = new int[MAXV+1][MAXDEGREE];
    public int degree[]  = new int[MAXV+1];
 
    lab6()
    {
        numv = count = 0;
        for (int i = 1; i <= MAXV; i++)
            degree[i] = 0;
    }
 
    void read(boolean c)
    {
        int a, b;
        Scanner sc = new Scanner(System.in);
        numv = sc.nextInt();
      
        int m = sc.nextInt();
      
        for (int i = 1; i <= m; i++)
        {
            a = sc.nextInt();
            b = sc.nextInt();
            newEdge(a, b, c);
        }
        sc.close();
    }
 
    void newEdge(int p, int q, boolean r)
    {
        if (degree[p] > MAXDEGREE)
            System.out.println("insertion exceeds max deg");
        edges[p][degree[p]] = q;
        degree[p]++;
        if (!r)
            newEdge(q, p, true);
        else
            count++;
    }
}

public class Lab6
{
    static final int MAXV = 100;
    static boolean processed[]  = new boolean[MAXV];
    static boolean discovered[] = new boolean[MAXV];
    static int parent[] = new int[MAXV];
 
    static void bfs(lab6 g, int start)
    {
        Queue<Integer> que = new LinkedList<Integer>();
        int i, v;
        que.offer(start);
        discovered[start] = true;
        while (!que.isEmpty())
        {
            v = que.remove();
            processed[v] = true;
            for (i = g.degree[v] - 1; i >= 0; i--)
            {
                if (!discovered[g.edges[v][i]])
                {
                    que.offer(g.edges[v][i]);
                    discovered[g.edges[v][i]] = true;
                    parent[g.edges[v][i]] = v;
                }
            }
        }
    }
 
    static void initSearch(lab6 g)
    {
        for (int i = 1; i <= g.numv; i++)
        {
            processed[i] = discovered[i] = false;
            parent[i] = -1;
        }
    }
 
    static void connectedComp(lab6 g)
    {
        int c;
        initSearch(g);
        c = 0;
        for (int i = 1; i <= g.numv; i++)
        {
            if (!discovered[i])
            {
                c++;
                bfs(g, i);
            }      
        }
        
        
        
            if(c==1){
                System.out.print(1);
                System.out.print(1);
            }
            else{
                System.out.print(0);
                System.out.print(c);
            }
    }
 
    static public void main(String[] args)
    {
        lab6 g = new lab6();
        g.read(false);
        connectedComp(g);
    }
}