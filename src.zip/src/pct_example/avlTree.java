package pct_example;
import java.util.Scanner;

public class avlTree {

	int data;
	avlTree left ,right;

	public avlTree(int data) {
		this.data=data;
		left = null;
		right = null;
	}
}

class tree{
	
	static avlTree root=null,temp;
	static  int l1=1,r1=1,flag=0;

	public avlTree add(avlTree n, int data)
	{
		if(n==null)
		{
			return new avlTree(data);
		}
		else if(data>n.data)
		{
			n.right=add(n.right,data);
		}
		else if(data<=n.data)
		{
			n.left=add(n.left,data);
		}
		return n;
	}

	public static int depth(avlTree n1)
	{

		if(n1==null)
		{
			return 0;
		}
		else {
			
			int rD = depth(n1.right);
			int lD = depth(n1.left);
			
			if (rD > lD) {
				if (Math.abs(rD-lD) > 1) {
					flag=1;
				}
				return (rD + 1);
			}
			else {
				if (Math.abs(rD-lD) > 1) {
					flag=1;
				}
				return (lD + 1);
			}

		}

	}

	public static void printt(avlTree n1)
	{
		if(n1!=null) {

			System.out.print(n1.data +" ");
			printt(n1.left);
			printt(n1.right);
		}
		else
		{
			return;
		}
	}

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		tree t = new tree();

		int i=0;
		do {
			i = s.nextInt();
			if(i>=0) {
				root = t.add(root, i);
			}
		}
		
		while (i>=0);

		int temp=depth(root);
		if(flag==1)
		{
			System.out.print("NOT");
		}else {
			printt(root);
		}
	}
}