package pct_example;

import java.util.Scanner;

public class keypad {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String outputCount= scan.nextLine();
		String str = scan.nextLine();
		char[] ch = str.toCharArray();
		char[] c0 = {' '};
		char[] c2 = {'a', 'b','c'};
		char[] c3 = {'d', 'e','f'};
		char[] c4 = {'g', 'h','i'};
		char[] c5 = {'j','k','l'};
		char[] c6 = {'m','n','o'};
		char[] c7 = {'p','q','r','s'};
		char[] c8 = {'t','u','v'};
		char[] c9 = {'w','x','y','z'};
		
		for(int i = 0; i<str.length();i++) {
			switch(str.charAt(0)) {
			case '0':
				break;
			case '1':
				break;
			case '2':
				break;
			case '3':
				break;
			case '4':
				break;
			case '5':
				break;
			case '6':
				break;
			case '7':
				break;
			case '8':
				break;
			case '9':
				break;
			}
		}
	}

}
