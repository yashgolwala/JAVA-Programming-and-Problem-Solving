import java.util.HashMap;
import java.util.Scanner;

public class lab5 {

	public static void main(String[] args) {
		lab5 o = new lab5();
		Scanner scan = new Scanner(System.in);
		String str = scan.nextLine();
		String letter = scan.nextLine();
		o.check(str,letter);
		scan.close();
	}

	private void check(String str, String letter) {
		HashMap<Character,Integer> hm = new HashMap<Character,Integer>();
		HashMap<Character,Integer> hm1 = new HashMap<Character,Integer>();
		
		if(str.length()>70|| letter.length()>str.length()) {
			return;
		}
				
		for(int i=0;i<letter.length();i++) {
			char c = letter.charAt(i);
			
			if(hm.containsKey(c)) {
				hm.put(c,hm.get(c)+1);
			}
			else {
				hm.put(c, 1);
			}
		}
		
		int a =0;
		int count=0;
		
		for(int i=0;i<str.length(); i++) {
			char c = str.charAt(i);
			if(hm.containsKey(c)) {
				if(hm1.containsKey(c)) {
					if(hm1.get(c)<hm.get(c)) {
						count++;
					}
					hm1.put(c,hm1.get(c)+1);
				}
				else {
					hm1.put(c,1);
					count++;
				}
			}
			
			if(count==letter.length()) {
				char ch = str.charAt(a);
				
				while(!hm1.containsKey(ch) || hm1.get(ch)>hm.get(ch)) {
					if(hm1.containsKey(ch) && hm1.get(ch) >hm.get(ch)) {
						hm1.put(ch,hm1.get(ch)-1);
					}
					a++;
					ch = str.charAt(a);
				}
				int n = str.length()+1;
				if(i-a+1< n) {
					System.out.println(""+str.substring(a,i+1));
					n = i-a+1;
				}
			}
			
		}
		
		return;
	}

}
