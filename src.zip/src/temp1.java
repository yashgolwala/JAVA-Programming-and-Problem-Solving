import java.util.ArrayList;
import java.util.Scanner;

public class temp1 {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		String[] ch = sc.nextLine().trim().split(" ");

		ArrayList<Integer> al = new ArrayList<>();

		for(int i=0; i<ch.length;i++) {
			al.add(Integer.parseInt(ch[i]));
		}

		ArrayList<Integer> al1 = new ArrayList<>();

		int count =0;

		for(int i =0 ; i<al.size()-1;i++) {
			count=1;
			if(al.get(i)>al.get(i+1)) {
				while(al.get(i)>al.get(i+1)) {
					count++;
					i++;
				}
				al1.add(count);
			}

			else {
				al1.add(count);
			}
		}
		System.out.print(al1);


	}
}
